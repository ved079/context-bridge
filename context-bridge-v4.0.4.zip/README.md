# Context Bridge

**Chrome Extension (Manifest V3)** — Capture conversations from Claude & ChatGPT as structured Markdown/JSON via internal APIs, with AI-powered summaries, insights, and enhanced exports. Built for developers who context-switch between AI agents.

## How It Works

Context Bridge calls each platform's **internal REST API** directly from the page context using your session cookies:

| Platform | API Endpoint | Auth |
|----------|-------------|------|
| **Claude** | `GET /api/organizations/{orgId}/chat_conversations/{convId}` | Same-origin cookies |
| **ChatGPT** | `GET /backend-api/conversations/{convId}` | Same-origin cookies |

Then optionally sends the captured data to a **local AI proxy server** (Express + z-ai SDK) for intelligent processing:

```
[Chrome Extension Popup]
         │
         ├── scrape ──▶ [Claude/ChatGPT API] ──▶ capture data
         │
         └── AI process ──▶ [Local Server :4321] ──▶ [z-ai SDK] ──▶ summary/insights/enhanced
```

## Features

- **One-click capture** — click the extension icon, hit "Capture", done
- **3 base export formats** — Full Markdown, Compact Markdown, JSON
- **AI-powered processing** (v3):
  - **Smart Summary** — LLM-generated concise overview with goals, key decisions, files, and unresolved items
  - **Insights** — Structured extraction of topics, tools used, decisions, files, action items, tech stack
  - **Enhanced Brief** — AI-rewritten context document for seamless agent switching
- **Tool call separation** — Claude Code file ops, bash commands extracted separately from text
- **Smart parsing** — Claude `chat_messages` + tree flattening; ChatGPT `mapping` tree traversal
- **Reliable downloads** — TextEncoder base64 + `chrome.downloads` API, emoji-safe
- **Dark theme UI** — zinc/indigo popup with stats, AI section, previews, toast notifications

## Quick Start

### 1. Install the Extension

1. Clone this repo: `git clone https://github.com/ved079/context-bridge.git`
2. Open **chrome://extensions** in Chrome
3. Enable **Developer mode** (top right toggle)
4. Click **Load unpacked** and select the `context-bridge/` folder

### 2. (Optional) Start the AI Server

The AI features require a local proxy server. Without it, the extension still works for capture and export — you just won't get the AI summary/insights/enhance buttons.

```bash
cd context-bridge/server
npm install
npm start
```

The server starts on `http://localhost:4321`. The extension auto-detects it.

**Requirements:** Node.js 18+

### 3. Capture & Process

1. Open a conversation on **claude.ai** or **chatgpt.com**
2. Click the **Context Bridge** extension icon
3. Click **Capture Conversation**
4. Export in any format, or click an AI button (Summary, Insights, Enhanced Brief)
5. AI results can be exported as `.md` or copied to clipboard

## Export Formats

| Format | Description | Use Case |
|--------|-------------|----------|
| **Full Markdown** | Headers, timestamps, tool calls in `<details>` blocks | Archive, review, documentation |
| **Compact Markdown** | Minimal token-saving format | Paste into a new AI chat session |
| **JSON** | Structured `{ messages, title, model }` | Programmatic use, backups |
| **AI Summary** | LLM-generated concise overview | Quick context, share with team |
| **AI Insights** | Topics, tools, decisions, files, action items | Project review, handoff |
| **Enhanced Brief** | AI-rewritten for agent continuity | Context switching between AI tools |

## Architecture

```
context-bridge/
├── manifest.json                 # MV3 manifest (v3.0)
├── background/
│   └── service-worker.js         # Message routing: popup <-> content scripts
├── content/
│   ├── common.js                  # Shared utilities: storage, detection, badge
│   ├── claude-api.js             # Claude scraper: org ID (3 fallbacks), API fetch
│   └── chatgpt-api.js           # ChatGPT scraper: mapping tree traversal
├── lib/
│   └── markdown-generator.js    # 6 export formats + GitHub footer
├── popup/
│   ├── popup.html                # Dark theme UI with AI features section
│   ├── popup.css                 # Zinc/indigo styling + AI button styles
│   └── popup.js                  # Capture + AI processing + downloads
├── server/                        # Local AI proxy (optional)
│   ├── package.json
│   └── server.js                 # Express + z-ai SDK endpoints
└── icons/
    ├── icon16.png
    ├── icon48.png
    └── icon128.png
```

### AI Server Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/health` | GET | Health check — extension pings this on open |
| `/api/summarize` | POST | Generate conversation summary |
| `/api/insights` | POST | Extract topics, tools, decisions, action items |
| `/api/enhance` | POST | Rewrite as context-switching brief |

All POST endpoints accept: `{ title, messages, platform, model }` and return `{ success, summary/insights/enhanced }`.

### Claude Parsing Details

- **Org ID detection** — 3 fallbacks: cookie scanning, `/api/organizations` API fetch, `__NEXT_DATA__` traversal
- **Content blocks** — separates `text`, `tool_use`, `tool_result`, `thinking`
- **Message merging** — consecutive assistant messages without tool boundaries get merged
- **Tree flattening** — fallback if `chat_messages` is empty

### ChatGPT Parsing Details

- **Mapping tree** — `{ mapping: { nodeId: { message, parent, children[] } } }`
- **Branch traversal** — follows the **last child** at each node (most recent)
- **Content types** — `text`, `code`, `execution_output`, `image_asset_pointer`, `citation`, `tether_browsing_result`, `multimodal_text`
- **Role filtering** — skips `system`, `tool`, `hidden` messages

## Privacy & Security

- **No external servers** (except your own localhost AI proxy)
- **No API keys in extension** — uses your existing session cookies
- **AI server runs locally** — your conversations never leave your machine
- **No data collection** — zero analytics, telemetry, or tracking

## Known Limitations

- **Requires active session** — must be logged into Claude or ChatGPT
- **AI features require Node.js** — the proxy server needs `npm install` + `npm start`
- **Claude org ID** — rare failures; refresh the page to fix
- **ChatGPT branches** — follows most recent only; regenerations not captured
- **Large conversations** — very long chats may take a few seconds

## License

MIT
