/**
 * Context Bridge — ChatGPT API Scraper (v4.0.3)
 * 
 * KEY FIX v4.0.3: ChatGPT's content-script fetch consistently returned 404.
 * Root cause: ChatGPT's page-level Service Worker intercepts/redirects internal
 * API requests from content scripts. The fix: delegate the fetch to the BACKGROUND
 * SERVICE WORKER, which operates outside the page's SW scope and has host_permissions
 * for chatgpt.com. The background fetch uses chrome.cookies to build proper auth.
 *
 * ChatGPT URL:  https://chatgpt.com/c/{convId}
 * ChatGPT API:  GET /backend-api/conversations/{convId}
 * Auth:        Sent automatically via cookies in background context
 */

(() => {
  "use strict";

  /* ── Fetch Conversation (delegated to background) ─────── */

  async function fetchConversation() {
    const convId = CBCommon.getConversationId();
    if (!convId) {
      throw new Error("No conversation found. Please open a ChatGPT chat first.");
    }

    console.log(`[CB] ChatGPT: requesting background fetch for ${convId}`);

    // Delegate to background service worker
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(
        { target: "background", action: "fetchChatgpt", convId: convId },
        (response) => {
          void chrome.runtime.lastError;
          if (chrome.runtime.lastError) {
            reject(new Error("Background communication failed: " + chrome.runtime.lastError.message));
            return;
          }
          if (!response) {
            reject(new Error("No response from background service worker."));
            return;
          }
          if (response.ok) {
            resolve(response.data);
          } else {
            reject(new Error(response.error || "Unknown ChatGPT fetch error"));
          }
        }
      );
    });
  }

  /* ── Parse API Response ─────────────────────────────────── */

  function parseConversation(apiData) {
    const title = apiData.title || apiData.name || "Untitled Conversation";
    const model = apiData.model || apiData.current_model || apiData.model_slug || "gpt";
    const mapping = apiData.mapping || {};

    console.log(`[CB] Parsing ChatGPT mapping with ${Object.keys(mapping).length} nodes`);

    const messages = [];

    // Find root node(s) — nodes with no parent
    const rootIds = Object.keys(mapping).filter(id => {
      const parent = mapping[id].parent;
      return parent === null || parent === "" || parent === undefined;
    });

    if (rootIds.length === 0) {
      console.warn("[CB] No root node found in mapping");
      return { title, model, messages, platform: "chatgpt", exportTimestamp: new Date().toISOString() };
    }

    // Traverse from root, following the main (latest) branch
    function traverseTree(nodeId) {
      const node = mapping[nodeId];
      if (!node || !node.message) return;

      const msg = node.message;
      const role = msg.author?.role || "unknown";

      if (role === "system" || role === "tool" || role === "hidden") return;
      if (!msg.content) return;

      const timestamp = msg.create_time
        ? new Date(msg.create_time * 1000).toISOString()
        : null;

      const parsed = {
        role: role === "user" ? "user" : "assistant",
        content: "",
        timestamp
      };

      const parts = msg.content.parts || [];

      if (typeof msg.content === "string") {
        parsed.content = msg.content;
      } else if (Array.isArray(parts)) {
        const textParts = [];
        const tools = [];

        for (const part of parts) {
          if (typeof part === "string") {
            textParts.push(part);
          } else if (part && typeof part === "object") {
            const contentType = part.content_type || part.type || "";

            switch (contentType) {
              case "text":
                textParts.push(part.text || "");
                break;
              case "code":
                textParts.push(`\`\`\`${part.language || ""}\n${part.text || ""}\n\`\`\``);
                break;
              case "execution_output":
              case "output":
                const outputText = typeof part.text === "string" ? part.text : JSON.stringify(part.text || part.data || "");
                textParts.push(`**Output:**\n\`\`\`\n${outputText}\n\`\`\``);
                break;
              case "image_asset_pointer":
              case "image":
                textParts.push("[Image attached]");
                break;
              case "citation":
                if (part.metadata?.url) textParts.push(`[Source: ${part.metadata.url}]`);
                break;
              case "multimodal_text":
                textParts.push(part.text || "[Multimodal content]");
                break;
              case "tether_browsing_result":
              case "tether_display":
                if (part.result) textParts.push(part.result);
                if (part.display) textParts.push(part.display);
                break;
              default:
                if (part.text) textParts.push(part.text);
                else if (part.asset_pointer) textParts.push("[Attached content]");
                else tools.push(part);
                break;
            }
          }
        }

        parsed.content = textParts.join("\n\n").trim();
        if (tools.length > 0) parsed.tools = tools;
      }

      if (parsed.content) {
        messages.push(parsed);
      }

      if (node.children && node.children.length > 0) {
        const nextId = node.children[node.children.length - 1];
        traverseTree(nextId);
      }
    }

    traverseTree(rootIds[0]);

    console.log(`[CB] Extracted ${messages.length} messages from ChatGPT tree`);

    return {
      title,
      model,
      messages,
      rawNodeCount: Object.keys(mapping).length,
      platform: "chatgpt",
      exportTimestamp: new Date().toISOString()
    };
  }

  /* ── Message Listener (from popup) ──────────────────────── */

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.target !== "content-chatgpt") return;

    switch (msg.action) {
      case "ping":
        sendResponse({ alive: true, platform: "chatgpt" });
        return false;

      case "detect":
        sendResponse({
          platform: "chatgpt",
          hasConversation: CBCommon.isChatPage(),
          conversationId: CBCommon.getConversationId(),
          url: window.location.href
        });
        return false;

      case "scrape":
        fetchConversation()
          .then(apiData => {
            const parsed = parseConversation(apiData);
            sendResponse({ ok: true, data: parsed });
          })
          .catch(err => {
            sendResponse({ ok: false, error: err.message });
          });
        return true;

      default:
        return false;
    }
  });

  console.log("[Context Bridge v4.0.3] ChatGPT API scraper loaded (background-fetch mode).");
})();
