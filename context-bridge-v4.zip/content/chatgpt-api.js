/**
 * Context Bridge — ChatGPT API Scraper (v4)
 * Fetches complete conversation data from ChatGPT's internal backend API.
 *
 * ChatGPT URL:  https://chatgpt.com/c/{convId}
 * ChatGPT API:  GET /backend-api/conversations/{convId}
 * Auth:        Same-origin cookies (automatic with credentials: "include")
 *
 * IMPORTANT: ChatGPT returns a `mapping` tree, NOT a flat `messages` array.
 * Each node has: { id, message, parent, children[] }
 * We traverse the tree following the active branch to collect messages in order.
 *
 * Note: ChatGPT may return 403/redirects if the conversation is very old or deleted.
 * The API uses CORS with access-control-allow-origin: https://chatgpt.com
 */

(() => {
  "use strict";

  /* ── Fetch Conversation ─────────────────────────────────── */

  async function fetchConversation() {
    const convId = CBCommon.getConversationId();
    if (!convId) {
      throw new Error("No conversation found. Please open a ChatGPT chat first.");
    }

    console.log(`[CB] Fetching ChatGPT conversation: ${convId.slice(0, 8)}...`);

    const url = `/backend-api/conversations/${convId}`;

    const resp = await fetch(url, {
      credentials: "include",
      headers: {
        "Accept": "application/json"
      }
    });

    if (!resp.ok) {
      const status = resp.status;
      // Try to read error body for diagnostics
      let errorBody = "";
      try { errorBody = await resp.text(); } catch(e) {}

      if (status === 401) throw new Error("Authentication failed. Please log into ChatGPT first.");
      if (status === 403) {
        // ChatGPT returns 403 for: deleted convs, shared convs from other users, or rate limits
        throw new Error(
          "Access denied (403) — This conversation may be shared/deleted, or ChatGPT blocked the request. " +
          "Try: (1) Open the conversation in ChatGPT first and wait for it to fully load, (2) Use your own conversations only."
        );
      }
      if (status === 404) {
        throw new Error(
          "Conversation not found (404) — The conversation may have been deleted, or the URL might use a short ID. " +
          "Conversation ID found: " + convId
        );
      }
      throw new Error(`ChatGPT API error ${status}${errorBody ? ': ' + errorBody.slice(0, 200) : ''}`);
    }

    const data = await resp.json();
    console.log(`[CB] ChatGPT API response — keys: ${Object.keys(data).join(", ")}`);

    return data;
  }

  /* ── Parse API Response ─────────────────────────────────── */

  function parseConversation(apiData) {
    const title = apiData.title || apiData.name || "Untitled Conversation";
    const model = apiData.model || apiData.current_model || "gpt";
    const mapping = apiData.mapping || {};

    console.log(`[CB] Parsing ChatGPT mapping with ${Object.keys(mapping).length} nodes`);

    const messages = [];

    // ChatGPT uses a tree structure in `mapping`:
    // - Each key is a node ID
    // - Each node: { id, message?, parent, children[] }
    // - Root node: parent is null or empty string
    // - We traverse: root → child[0] → child[0] → ... (following active branch)

    // Find root node(s) — nodes with no parent
    const rootIds = Object.keys(mapping).filter(id => {
      const parent = mapping[id].parent;
      return parent === null || parent === "" || parent === undefined;
    });

    if (rootIds.length === 0) {
      console.warn("[CB] No root node found in mapping");
      return { title, model, messages, platform: "chatgpt", exportTimestamp: new Date().toISOString() };
    }

    // Traverse from root, following the main (latest) branch
    function traverseTree(nodeId) {
      const node = mapping[nodeId];
      if (!node || !node.message) return;

      const msg = node.message;
      const role = msg.author?.role || "unknown";

      // Skip system messages and hidden messages
      if (role === "system" || role === "tool" || role === "hidden") return;

      // Skip messages with empty or null content
      if (!msg.content) return;

      const timestamp = msg.create_time
        ? new Date(msg.create_time * 1000).toISOString()
        : null;

      const parsed = {
        role: role === "user" ? "user" : "assistant",
        content: "",
        timestamp
      };

      // ChatGPT content format: { content_type, parts[] }
      // parts can be: string, { content_type, text, ... }, { content_type, asset_pointer, ... }
      const parts = msg.content.parts || [];

      // If content is a string directly (rare, but handle it)
      if (typeof msg.content === "string") {
        parsed.content = msg.content;
      } else if (Array.isArray(parts)) {
        const textParts = [];
        const tools = [];
        const files = [];

        for (const part of parts) {
          if (typeof part === "string") {
            // Plain text part
            textParts.push(part);
          } else if (part && typeof part === "object") {
            const contentType = part.content_type || part.type || "";

            switch (contentType) {
              case "text":
                textParts.push(part.text || "");
                break;

              case "code":
                // Code execution block — include with language tag
                const lang = part.language || "";
                textParts.push(`\`\`\`${lang}\n${part.text || ""}\n\`\`\``);
                break;

              case "execution_output":
              case "output":
                // Code execution output
                const outputText = typeof part.text === "string" ? part.text : JSON.stringify(part.text || part.data || "");
                textParts.push(`**Output:**\n\`\`\`\n${outputText}\n\`\`\``);
                break;

              case "image_asset_pointer":
              case "image":
                textParts.push("[Image attached]");
                break;

              case "citation":
                // Web search citation
                if (part.metadata?.url) {
                  textParts.push(`[Source: ${part.metadata.url}]`);
                }
                break;

              case "multimodal_text":
                // Image with text
                textParts.push(part.text || "[Multimodal content]");
                break;

              case "tether_browsing_result":
              case "tether_display":
                // Web browsing results
                if (part.result) textParts.push(part.result);
                if (part.display) textParts.push(part.display);
                break;

              default:
                // Unknown type — try to extract text
                if (part.text) {
                  textParts.push(part.text);
                } else if (part.asset_pointer) {
                  textParts.push("[Attached content]");
                } else {
                  // Store as unknown tool data
                  tools.push(part);
                }
                break;
            }
          }
        }

        parsed.content = textParts.join("\n\n").trim();
        if (tools.length > 0) parsed.tools = tools;
        if (files.length > 0) parsed.files = files;
      }

      // Only add messages with actual content
      if (parsed.content) {
        messages.push(parsed);
      }

      // Follow to next node (children)
      if (node.children && node.children.length > 0) {
        // Use the last child (most recent edit/continuation)
        const nextId = node.children[node.children.length - 1];
        traverseTree(nextId);
      }
    }

    // Start traversal from the root
    traverseTree(rootIds[0]);

    console.log(`[CB] Extracted ${messages.length} messages from ChatGPT tree`);

    return {
      title,
      model,
      messages,
      rawNodeCount: Object.keys(mapping).length,
      platform: "chatgpt",
      exportTimestamp: new Date().toISOString()
    };
  }

  /* ── Message Listener (from popup) ──────────────────────── */

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.target !== "content-chatgpt") return;

    switch (msg.action) {
      case "ping":
        sendResponse({ alive: true, platform: "chatgpt" });
        return false;

      case "detect":
        sendResponse({
          platform: "chatgpt",
          hasConversation: CBCommon.isChatPage(),
          conversationId: CBCommon.getConversationId(),
          url: window.location.href
        });
        return false;

      case "scrape":
        fetchConversation()
          .then(apiData => {
            const parsed = parseConversation(apiData);
            sendResponse({ ok: true, data: parsed });
          })
          .catch(err => {
            sendResponse({ ok: false, error: err.message });
          });
        return true; // async

      default:
        return false;
    }
  });

  console.log("[Context Bridge v4] ChatGPT API scraper loaded.");
})();
