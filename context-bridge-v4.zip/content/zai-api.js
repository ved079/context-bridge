/**
 * Context Bridge — Z.ai API Scraper (v4)
 * Fetches complete conversation data from Z.ai's internal REST API.
 *
 * Z.ai URL:  https://chat.z.ai/c/{convId}
 * Z.ai API:  GET /api/v1/chats/{id}
 * Auth:      Bearer token (from cookie or page localStorage)
 *
 * IMPORTANT: Z.ai uses a tree structure for messages (like ChatGPT's mapping).
 * Each message node: { id, parentId, childrenIds[], role, content (string), model, timestamp }
 * We traverse from root → latest child to get messages in order.
 *
 * Tech stack: Svelte + Vite SPA, Open WebUI fork.
 * Token available via: cookie "token" (primary) or localStorage "token" (fallback).
 */

(() => {
  "use strict";

  /* ── Token Extraction ────────────────────────────────────── */
  // Content scripts run in an isolated world and CANNOT access page's localStorage.
  // Z.ai stores the JWT in BOTH a cookie named "token" AND localStorage.token.
  // Cookies ARE accessible from content scripts, so we try that first.
  // If cookie fails, we inject a script into the main world via the background
  // service worker (using chrome.scripting.executeScript with world: "MAIN").

  let cachedToken = null;

  async function getToken() {
    if (cachedToken) return cachedToken;

    // Method 1: Read from cookie (works in content script isolated world)
    try {
      const cookies = document.cookie;
      // Match cookie named "token" — handle URL-encoded values
      const match = cookies.match(/(?:^|;\s*)token=([^;]+)/);
      if (match && match[1]) {
        const token = decodeURIComponent(match[1]).trim();
        if (token && token.length > 10) {
          cachedToken = token;
          console.log("[CB] Z.ai token found in cookie");
          return cachedToken;
        }
      }
    } catch (e) {
      console.log("[CB] Cookie read failed:", e.message);
    }

    // Method 2: Inject script to read localStorage (may be blocked by CSP)
    try {
      const token = await getTokenFromPage();
      if (token && token.length > 10) {
        cachedToken = token;
        console.log("[CB] Z.ai token found via page injection");
        return cachedToken;
      }
    } catch (e) {
      console.log("[CB] Page injection failed:", e.message);
    }

    // Method 3: Use chrome.scripting to execute in MAIN world (MV3 approach)
    try {
      const token = await getTokenViaScripting();
      if (token && token.length > 10) {
        cachedToken = token;
        console.log("[CB] Z.ai token found via chrome.scripting");
        return cachedToken;
      }
    } catch (e) {
      console.log("[CB] chrome.scripting failed:", e.message);
    }

    // Method 4: Try without token (cookies might be enough for auth)
    console.log("[CB] No explicit token found, will try cookie-only auth");
    cachedToken = ""; // empty string = try without Bearer header
    return cachedToken;
  }

  function getTokenFromPage() {
    return new Promise((resolve) => {
      const handler = (event) => {
        if (event.source !== window) return;
        if (!event.data || event.data.type !== "__CB_ZAI_TOKEN__") return;
        window.removeEventListener("message", handler);
        clearTimeout(timeout);
        resolve(event.data.token);
      };

      const timeout = setTimeout(() => {
        window.removeEventListener("message", handler);
        resolve(null);
      }, 1500);

      window.addEventListener("message", handler);

      // Inject script to read localStorage
      const script = document.createElement("script");
      script.textContent = `(function(){try{var t=localStorage.getItem('token');window.postMessage({type:'__CB_ZAI_TOKEN__',token:t},'*')}catch(e){window.postMessage({type:'__CB_ZAI_TOKEN__',token:null},'*')}})();`;
      try {
        (document.head || document.documentElement).appendChild(script);
        script.remove();
      } catch (e) {
        clearTimeout(timeout);
        window.removeEventListener("message", handler);
        resolve(null);
      }
    });
  }

  async function getTokenViaScripting() {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage(
        { target: "background", action: "getZaiToken" },
        (response) => {
          void chrome.runtime.lastError;
          resolve(response?.token || null);
        }
      );
    });
  }

  /* ── Fetch Conversation ─────────────────────────────────── */

  async function fetchConversation() {
    const convId = CBCommon.getConversationId();
    if (!convId) {
      throw new Error("No conversation found. Please open a Z.ai chat first.");
    }

    console.log(`[CB] Fetching Z.ai conversation: ${convId.slice(0, 8)}...`);

    const token = await getToken();

    // Build headers — include Bearer token if available
    const headers = {
      "Accept": "application/json"
    };

    if (token && token.length > 0) {
      headers["Authorization"] = `Bearer ${token}`;
    }

    const url = `/api/v1/chats/${convId}`;

    const resp = await fetch(url, {
      credentials: "include",
      headers
    });

    if (!resp.ok) {
      const status = resp.status;
      // Try to get error body for debugging
      let bodyText = "";
      try { bodyText = await resp.text(); } catch(e) {}

      if (status === 401) throw new Error("Authentication failed (401). Please log into chat.z.ai and refresh the page.");
      if (status === 403) throw new Error("Access denied (403) — this conversation may be private or deleted.");
      if (status === 404) throw new Error("Conversation not found (404). It may have been deleted or the URL is incorrect.");
      throw new Error(`Z.ai API returned ${status} ${resp.statusText}${bodyText ? ': ' + bodyText.slice(0, 200) : ''}`);
    }

    const data = await resp.json();
    console.log(`[CB] Z.ai API response — keys: ${Object.keys(data).join(", ")}`);

    return data;
  }

  /* ── Parse API Response ─────────────────────────────────── */

  function parseConversation(apiData) {
    const title = apiData.title || apiData.name || "Untitled Conversation";

    // Model can be in various locations
    const model =
      apiData.model ||
      (apiData.meta && Array.isArray(apiData.meta.models) && apiData.meta.models[0]) ||
      (apiData.chat && apiData.chat.model) ||
      "GLM";

    // Messages live in a map/dictionary keyed by message UUID
    let messagesMap = null;

    // Path 1: Direct messages object
    if (apiData.messages && typeof apiData.messages === "object" && !Array.isArray(apiData.messages)) {
      messagesMap = apiData.messages;
    }
    // Path 2: Nested in chat object
    else if (apiData.chat && apiData.chat.messages) {
      messagesMap = apiData.chat.messages;
    }
    // Path 3: Array of message objects
    else if (Array.isArray(apiData.messages)) {
      // Convert array to map for uniform processing
      messagesMap = {};
      for (const msg of apiData.messages) {
        if (msg.id) messagesMap[msg.id] = msg;
      }
    }
    // Path 4: Try to find message-like objects in response
    else {
      console.log("[CB] Z.ai response structure — dumping top-level keys and types:");
      for (const key of Object.keys(apiData)) {
        const val = apiData[key];
        const type = Array.isArray(val) ? `array[${val.length}]` : typeof val;
        console.log(`  ${key}: ${type}`);
        if (val && typeof val === "object" && !Array.isArray(val)) {
          console.log(`    sub-keys: ${Object.keys(val).slice(0, 10).join(", ")}`);
        }
      }

      // Heuristic scan for objects that look like message nodes
      messagesMap = {};
      for (const key of Object.keys(apiData)) {
        const val = apiData[key];
        if (val && typeof val === "object" && !Array.isArray(val) &&
            val.role && (val.parentId !== undefined || val.content !== undefined || val.childrenIds)) {
          messagesMap[val.id || key] = val;
        }
      }
      if (Object.keys(messagesMap).length === 0) messagesMap = null;
    }

    if (!messagesMap || Object.keys(messagesMap).length === 0) {
      console.warn("[CB] No messages found in Z.ai response. Full structure:");
      console.log(JSON.stringify(apiData).slice(0, 2000));
      return { title, model, messages: [], platform: "zai", exportTimestamp: new Date().toISOString() };
    }

    // ── Tree Traversal ─────────────────────────────────────
    const messages = [];
    const nodeCount = Object.keys(messagesMap).length;

    // If nodes have parentId, use tree traversal
    const hasTree = Object.values(messagesMap).some(n => n.parentId !== undefined);
    // If nodes have childrenIds, also tree traversal
    const hasChildren = Object.values(messagesMap).some(n => n.childrenIds || n.children);

    if (hasTree || hasChildren) {
      // Tree traversal: find root (no parentId), follow children
      const rootIds = Object.keys(messagesMap).filter(id => {
        const node = messagesMap[id];
        return !node.parentId || node.parentId === null || node.parentId === "" || node.parentId === undefined;
      });

      if (rootIds.length === 0) {
        // Fallback: just use all nodes sorted by timestamp
        console.warn("[CB] No root node found, falling back to timestamp sort");
        const sorted = Object.values(messagesMap)
          .filter(n => n.role === "user" || n.role === "assistant")
          .sort((a, b) => (a.timestamp || 0) - (b.timestamp || 0));
        for (const node of sorted) {
          addMessage(messages, node);
        }
      } else {
        console.log(`[CB] Parsing Z.ai tree: ${nodeCount} nodes, ${rootIds.length} root(s)`);
        traverseTree(rootIds[0], messagesMap, messages, new Set());
      }
    } else {
      // Linear array — just sort by timestamp
      console.log(`[CB] Parsing Z.ai linear messages: ${nodeCount} messages`);
      const sorted = Object.values(messagesMap)
        .filter(n => n.role === "user" || n.role === "assistant")
        .sort((a, b) => (a.timestamp || 0) - (b.timestamp || 0));
      for (const node of sorted) {
        addMessage(messages, node);
      }
    }

    console.log(`[CB] Extracted ${messages.length} messages from Z.ai`);

    return {
      title,
      model,
      messages,
      rawNodeCount: nodeCount,
      platform: "zai",
      exportTimestamp: new Date().toISOString()
    };
  }

  function addMessage(messages, node) {
    const role = node.role || "unknown";
    if (role === "system" || role === "tool" || role === "hidden") return;

    const content = node.content || "";
    const timestamp = node.timestamp
      ? (typeof node.timestamp === "number" ? new Date(node.timestamp * 1000).toISOString() : new Date(node.timestamp).toISOString())
      : null;

    if (content && content.trim()) {
      const parsed = {
        role: role === "user" ? "user" : "assistant",
        content: content.trim(),
        timestamp
      };

      if (node.files && Array.isArray(node.files) && node.files.length > 0) {
        parsed.files = node.files;
      }

      messages.push(parsed);
    }
  }

  function traverseTree(nodeId, messagesMap, messages, visited) {
    if (visited.has(nodeId)) return;
    visited.add(nodeId);

    const node = messagesMap[nodeId];
    if (!node) return;

    addMessage(messages, node);

    const children = node.childrenIds || node.children || [];
    if (children.length > 0) {
      const nextId = children[children.length - 1];
      traverseTree(nextId, messagesMap, messages, visited);
    }
  }

  /* ── Message Listener (from popup) ──────────────────────── */

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.target !== "content-zai") return;

    switch (msg.action) {
      case "ping":
        sendResponse({ alive: true, platform: "zai" });
        return false;

      case "detect":
        sendResponse({
          platform: "zai",
          hasConversation: CBCommon.isChatPage(),
          conversationId: CBCommon.getConversationId(),
          url: window.location.href
        });
        return false;

      case "scrape":
        fetchConversation()
          .then(apiData => {
            const parsed = parseConversation(apiData);
            sendResponse({ ok: true, data: parsed });
          })
          .catch(err => {
            sendResponse({ ok: false, error: err.message });
          });
        return true; // async response

      default:
        return false;
    }
  });

  console.log("[Context Bridge v4] Z.ai API scraper loaded.");
})();
