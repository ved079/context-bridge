/**
 * Context Bridge — Background Service Worker (v4)
 * Minimal: just routes messages between popup ↔ content scripts.
 */

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  // Only handle messages explicitly targeted at background
  if (msg.target !== "background") return false;

  // Handle Z.ai token extraction via chrome.scripting (MAIN world)
  if (msg.action === "getZaiToken") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tab = tabs[0];
      if (!tab || !tab.url || !tab.url.includes("z.ai")) {
        sendResponse({ token: null });
        return;
      }
      // Execute in the MAIN world to access page's localStorage
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        world: "MAIN",
        func: () => {
          try { return localStorage.getItem('token'); }
          catch(e) { return null; }
        }
      }).then((results) => {
        const token = results && results[0] && results[0].result;
        sendResponse({ token: token || null });
      }).catch((err) => {
        console.error("[CB] scripting.executeScript failed:", err);
        sendResponse({ token: null });
      });
    });
    return true; // async
  }

  // Handle download requests directly (don't forward to content script)
  if (msg.action === "download") {
    // Convert data URL to blob URL for chrome.downloads
    fetch(msg.dataUrl)
      .then(resp => resp.blob())
      .then(blob => {
        const url = URL.createObjectURL(blob);
        chrome.downloads.download({
          url: url,
          filename: msg.filename,
          saveAs: true
        }, (downloadId) => {
          if (downloadId) {
            sendResponse({ ok: true, downloadId });
          } else {
            sendResponse({ error: chrome.runtime.lastError?.message || "Download failed" });
          }
        });
      })
      .catch(err => sendResponse({ error: err.message }));
    return true; // async
  }

  // Route all other messages to correct content script based on active tab URL
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs[0];
    if (!tab || !tab.url || !tab.url.startsWith("http")) {
      sendResponse({ error: "No supported page open" });
      return;
    }

    // Determine which content script to message
    let target;
    if (tab.url.includes("claude.ai")) {
      target = "content-claude";
    } else if (tab.url.includes("chatgpt.com") || tab.url.includes("chat.openai.com")) {
      target = "content-chatgpt";
    } else if (tab.url.includes("z.ai")) {
      target = "content-zai";
    } else {
      sendResponse({ error: "Not a supported AI chat page" });
      return;
    }

    // Forward the message (without the target: "background" field)
    const forwardMsg = { ...msg };
    delete forwardMsg.target;

    chrome.tabs.sendMessage(tab.id, forwardMsg, (response) => {
      if (chrome.runtime.lastError) {
        sendResponse({ error: "Could not reach content script. Try refreshing the chat page." });
      } else {
        sendResponse(response);
      }
    });
  });

  return true; // async response
});

// Clean up on install/update
chrome.runtime.onInstalled.addListener(() => {
  console.log("[Context Bridge v4] Extension installed/updated.");
});

console.log("[Context Bridge v4] Background service worker started.");
