/**
 * Context Bridge — ChatGPT API Scraper (v4)
 * Fetches complete conversation data from ChatGPT's internal backend API.
 *
 * ChatGPT URL:  https://chatgpt.com/c/{convId}
 * ChatGPT API:  GET /backend-api/conversations/{convId}
 * Auth:        Same-origin cookies (automatic with credentials: "include")
 *
 * IMPORTANT: ChatGPT returns a `mapping` tree, NOT a flat `messages` array.
 * Each node has: { id, message, parent, children[] }
 * We traverse the tree following the active branch to collect messages in order.
 */

(() => {
  "use strict";

  /* ── Fetch Conversation ─────────────────────────────────── */

  async function fetchConversation() {
    const convId = CBCommon.getConversationId();
    if (!convId) {
      throw new Error("No conversation found. Please open a ChatGPT chat first.");
    }

    console.log(`[CB] Fetching ChatGPT conversation: ${convId} (length: ${convId.length})`);
    console.log(`[CB] Current URL: ${window.location.href}`);

    // Try multiple endpoint variations
    const endpoints = [
      `/backend-api/conversations/${convId}`,
      `/backend-api/conversation/${convId}`,
    ];

    let lastError = null;

    for (const url of endpoints) {
      console.log(`[CB] Trying: ${url}`);

      const resp = await fetch(url, {
        credentials: "include",
        headers: {
          "Accept": "application/json"
        }
      });

      console.log(`[CB] Response: ${resp.status} ${resp.statusText} (type: ${resp.headers.get('content-type')})`);

      if (resp.ok) {
        const data = await resp.json();
        console.log(`[CB] ChatGPT API response — keys: ${Object.keys(data).join(", ")}`);
        return data;
      }

      // Read error body
      let errorBody = "";
      try { errorBody = await resp.text(); } catch(e) {}

      lastError = { status: resp.status, statusText: resp.statusText, body: errorBody, url };

      // Skip 404 for this endpoint and try next
      if (resp.status === 404) {
        console.log(`[CB] 404 on ${url} — body: "${errorBody}"`);
        continue;
      }

      // 403 or 401 is auth-related, no point trying other endpoints
      break;
    }

    // All endpoints failed
    const err = lastError || { status: "?", statusText: "unknown", body: "", url: "?" };
    console.error("[CB] All ChatGPT endpoints failed:", err);

    if (err.status === 401) {
      throw new Error("Authentication failed. Please log into ChatGPT first.");
    }
    if (err.status === 403) {
      throw new Error(
        "Access denied (403) — ChatGPT blocked the request. " +
        "This can happen with shared conversations or if ChatGPT has updated its API. " +
        "Try opening this conversation in ChatGPT directly first."
      );
    }
    if (err.status === 404) {
      throw new Error(
        `ChatGPT returned 404 for conversation "${convId}". ` +
        "This usually means: (1) the conversation was deleted, " +
        "(2) it's a shared link (not your conversation), or " +
        "(3) ChatGPT changed their internal API."
      );
    }
    throw new Error(`ChatGPT API error ${err.status}${err.body ? ': ' + err.body.slice(0, 200) : ''}`);
  }

  /* ── Parse API Response ─────────────────────────────────── */

  function parseConversation(apiData) {
    const title = apiData.title || apiData.name || "Untitled Conversation";
    const model = apiData.model || apiData.current_model || apiData.model_slug || "gpt";
    const mapping = apiData.mapping || {};

    console.log(`[CB] Parsing ChatGPT mapping with ${Object.keys(mapping).length} nodes`);

    const messages = [];

    // Find root node(s) — nodes with no parent
    const rootIds = Object.keys(mapping).filter(id => {
      const parent = mapping[id].parent;
      return parent === null || parent === "" || parent === undefined;
    });

    if (rootIds.length === 0) {
      console.warn("[CB] No root node found in mapping");
      return { title, model, messages, platform: "chatgpt", exportTimestamp: new Date().toISOString() };
    }

    // Traverse from root, following the main (latest) branch
    function traverseTree(nodeId) {
      const node = mapping[nodeId];
      if (!node || !node.message) return;

      const msg = node.message;
      const role = msg.author?.role || "unknown";

      if (role === "system" || role === "tool" || role === "hidden") return;
      if (!msg.content) return;

      const timestamp = msg.create_time
        ? new Date(msg.create_time * 1000).toISOString()
        : null;

      const parsed = {
        role: role === "user" ? "user" : "assistant",
        content: "",
        timestamp
      };

      const parts = msg.content.parts || [];

      if (typeof msg.content === "string") {
        parsed.content = msg.content;
      } else if (Array.isArray(parts)) {
        const textParts = [];
        const tools = [];

        for (const part of parts) {
          if (typeof part === "string") {
            textParts.push(part);
          } else if (part && typeof part === "object") {
            const contentType = part.content_type || part.type || "";

            switch (contentType) {
              case "text":
                textParts.push(part.text || "");
                break;
              case "code":
                textParts.push(`\`\`\`${part.language || ""}\n${part.text || ""}\n\`\`\``);
                break;
              case "execution_output":
              case "output":
                const outputText = typeof part.text === "string" ? part.text : JSON.stringify(part.text || part.data || "");
                textParts.push(`**Output:**\n\`\`\`\n${outputText}\n\`\`\``);
                break;
              case "image_asset_pointer":
              case "image":
                textParts.push("[Image attached]");
                break;
              case "citation":
                if (part.metadata?.url) textParts.push(`[Source: ${part.metadata.url}]`);
                break;
              case "multimodal_text":
                textParts.push(part.text || "[Multimodal content]");
                break;
              case "tether_browsing_result":
              case "tether_display":
                if (part.result) textParts.push(part.result);
                if (part.display) textParts.push(part.display);
                break;
              default:
                if (part.text) textParts.push(part.text);
                else if (part.asset_pointer) textParts.push("[Attached content]");
                else tools.push(part);
                break;
            }
          }
        }

        parsed.content = textParts.join("\n\n").trim();
        if (tools.length > 0) parsed.tools = tools;
      }

      if (parsed.content) {
        messages.push(parsed);
      }

      if (node.children && node.children.length > 0) {
        const nextId = node.children[node.children.length - 1];
        traverseTree(nextId);
      }
    }

    traverseTree(rootIds[0]);

    console.log(`[CB] Extracted ${messages.length} messages from ChatGPT tree`);

    return {
      title,
      model,
      messages,
      rawNodeCount: Object.keys(mapping).length,
      platform: "chatgpt",
      exportTimestamp: new Date().toISOString()
    };
  }

  /* ── Message Listener (from popup) ──────────────────────── */

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.target !== "content-chatgpt") return;

    switch (msg.action) {
      case "ping":
        sendResponse({ alive: true, platform: "chatgpt" });
        return false;

      case "detect":
        sendResponse({
          platform: "chatgpt",
          hasConversation: CBCommon.isChatPage(),
          conversationId: CBCommon.getConversationId(),
          url: window.location.href
        });
        return false;

      case "scrape":
        fetchConversation()
          .then(apiData => {
            const parsed = parseConversation(apiData);
            sendResponse({ ok: true, data: parsed });
          })
          .catch(err => {
            sendResponse({ ok: false, error: err.message });
          });
        return true;

      default:
        return false;
    }
  });

  console.log("[Context Bridge v4] ChatGPT API scraper loaded.");
})();
